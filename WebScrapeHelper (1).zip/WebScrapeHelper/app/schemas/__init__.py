"""
Schema modules for the application.

This package contains the Pydantic schema models for
data validation and serialization/deserialization.
"""