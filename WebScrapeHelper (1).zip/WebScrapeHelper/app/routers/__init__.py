"""
Router modules for the application.

This package contains the API routers for different parts of the application,
organized by functionality.
"""