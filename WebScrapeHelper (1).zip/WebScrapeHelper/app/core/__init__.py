"""
Core modules for the application.

This package contains core functionality used throughout the application,
such as configuration, logging, and utility functions.
"""